const AWS = require('aws-sdk');
const mysql = require('mysql');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const dbConfig = {
    host: process.env.RDS_ENDPOINT,
    user: process.env.DB_USERNAME,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME
};

exports.handler = async (event) => {
    let connection;
    try {
        console.log('Received event:', JSON.stringify(event, null, 2));

        // 클라이언트에서 받은 사용자 이름(또는 이메일)과 비밀번호 파싱
        const { username, password } = event;

        connection = mysql.createConnection(dbConfig);

        const searchQuery = 'SELECT password FROM Customers WHERE username = ? OR email = ?';
        const userValues = [username, username]; // 사용자 이름 또는 이메일로 검색

        const userResult = await new Promise((resolve, reject) => {
    connection.query(searchQuery, userValues, (error, results) => {
        if (error) {
            reject(error);
        } else {
            resolve(results.length > 0 ? results[0] : null);
        }
    });
});

if (!userResult) {
    throw new Error('User does not exist.');
}

const passwordMatch = await bcrypt.compare(password, userResult.password);
if (!passwordMatch) {
    throw new Error('Password does not match.');
}

// JWT 토큰 생성, 사용자의 username과 email을 포함
const token = jwt.sign(
    {
        username: username // DB에서 검색된 사용자 이름
    },
    process.env.JWT_SECRET_KEY,
    { expiresIn: '1h' }
);

        const response = {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*', // 적절한 CORS 설정 필요
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                message: 'Login successful',
                token: token
            })
        };

        console.log('User logged in successfully:', username);
        return response;

    } catch (error) {
        console.error('Login error:', error);
        return {
            statusCode: error.statusCode || 401,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ message: error.message || 'Login failed' })
        };
    } finally {
        if (connection && connection.end) {
            connection.end();
        }
    }
};
