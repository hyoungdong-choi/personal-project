const aws = require('aws-sdk');
const dynamoDB = new aws.DynamoDB.DocumentClient({
    region: 'ap-northeast-2', // Region 서울로 변경 필수!
    apiVersion: '2012-08-10'
});

exports.handler = async (event) => {
    try {
        console.log('Received event:', JSON.stringify(event, null, 2));

        // Check if the event has records
        const { Records } = event;
        if (!Records || Records.length === 0) {
            throw new Error("No records found in the event");
        }

        // Process each record from the event
        const processTasks = Records.map(async (record) => {
            // Parse the JSON message body
            const body = JSON.parse(record.body);
            console.log("Processing message body:", body);

            // Prepare parameters for DynamoDB
            const params = {
                TableName: 'new-reserv-rds-username-for-email', // DynamoDB table name
                Item: {
                    username: body.username,
                    email: body.email
                }
            };

            // Write the item to DynamoDB
            await dynamoDB.put(params).promise();
            console.log('Item successfully written to DynamoDB:', params.Item);
        });

        // Wait for all write operations to complete
        await Promise.all(processTasks);
        console.log('All tasks completed successfully.');

        // Return a successful response
        return { statusCode: 200, body: JSON.stringify({ message: 'Processing completed' }) };
    } catch (error) {
        // Log and return any errors that occurred
        console.error('An error occurred while processing the event:', error);
        return { statusCode: 500, body: JSON.stringify({ message: 'Error while processing the event', error: error.toString() }) };
    }
};
