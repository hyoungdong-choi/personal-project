const AWS = require('aws-sdk');
const dynamoDB = new AWS.DynamoDB.DocumentClient();
const jwt = require('jsonwebtoken');

exports.handler = async (event) => {
    console.log('Received event:', JSON.stringify(event, null, 2));

    // 요청 헤더에서 토큰 추출
    const headers = event.headers;
    const token = headers.Authorization || headers.authorization;
    
    if (!token) {
        return response(401, 'Authorization token not provided');
    }

    // 'Bearer' 접두어가 누락된 경우를 처리하는 로직 추가
    const tokenValue = token.startsWith('Bearer ') ? token.split(' ')[1] : token;

    // 토큰 디코드 및 검증
    let decoded;
    try {
        decoded = jwt.verify(tokenValue, process.env.JWT_SECRET_KEY);
        console.log('Decoded JWT:', decoded);
    } catch (error) {
        console.error(error);
        return {
            statusCode: 401,
            body: 'Invalid token',
            headers: {
                'Access-Control-Allow-Origin': '*', // 모든 Origin에서 접근 허용 (보안 상 주의)
                'Access-Control-Allow-Headers': 'Content-Type,Authorization', // 필요한 헤더 추가
                'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE', // 필요한 메서드 추가
            },
        };
    }

    // JWT 토큰에서 사용자 ID 추출
    const username = decoded.username;

    // DynamoDB를 사용하여 예약 정보를 검색합니다.
    const reservationInfo = await getReservationInfoFromDynamoDB(username);

    // 검색된 예약 정보가 없는 경우 에러 메시지를 반환합니다.
    if (!reservationInfo) {
        return {
            statusCode: 404,
            body: '예약정보가 없습니다.',
            headers: {
                'Access-Control-Allow-Origin': '*', // 모든 Origin에서 접근 허용 (보안 상 주의)
                'Access-Control-Allow-Headers': 'Content-Type,Authorization', // 필요한 헤더 추가
                'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE', // 필요한 메서드 추가
            },
        };
    }

    // 검색된 예약 정보를 JSON 형태로 반환합니다.
    return {
        statusCode: 200,
        body: JSON.stringify(reservationInfo),
        headers: {
            'Access-Control-Allow-Origin': '*', // 모든 Origin에서 접근 허용 (보안 상 주의)
            'Access-Control-Allow-Headers': 'Content-Type,Authorization', // 필요한 헤더 추가
            'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE', // 필요한 메서드 추가
        },
    };
};

async function getReservationInfoFromDynamoDB(username) {
    const params = {
        TableName: 'Reservation_Info', // 실제 테이블 이름으로 변경되었습니다.
        Key: {
            'username': username, // 파티션 키 이름으로 변경되었습니다.
        },
    };

    try {
        const data = await dynamoDB.get(params).promise();
        if (!data || !data.Item) {
            throw new Error('No reservation info found for this user');
        }
        return data.Item;
    } catch (error) {
        console.error(error);
        throw error;
    }
}