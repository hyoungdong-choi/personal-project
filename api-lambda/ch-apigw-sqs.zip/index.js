const aws = require('aws-sdk');
const sqs = new aws.SQS({ apiVersion: '2012-11-05' });

exports.handler = async (event) => {
    try {
        // Parse the form data from the event body
        console.log('Received event:', JSON.stringify(event)); // 전체 이벤트 로깅
        if (!event.body) {
            throw new Error('No body found in the event');
        }

        let formData = JSON.parse(event.body); // 이 부분에서 error가 발생할 수 있음

        // Check if all required fields are present
        const requiredFields = ["userId", "name", "age", "departureDate", "arrivalDate", "departurePoint", "destination", "airline", "price", "flightTime"];
        for (const field of requiredFields) {
            if (!formData[field]) {
                throw new Error(`${field} is required`);
            }
        }

        // Prepare the SQS message
        const sqsMessage = {
            userId: formData.userId,
            // Add all other fields
            name: formData.name,
            age: formData.age,
            departureDate: formData.departureDate,
            arrivalDate: formData.arrivalDate,
            departurePoint: formData.departurePoint,
            destination: formData.destination,
            airline: formData.airline,
            price: formData.price,
            flightTime: formData.flightTime
        };

        // SQS message attributes (optional, can be removed if not needed)
        const messageAttributes = {
            userId: {
                DataType: 'String',
                StringValue: formData.userId
            }
        };

        // SQS message parameters
        const params = {
            MessageBody: JSON.stringify(sqsMessage),
            QueueUrl: 'https://sqs.ap-northeast-2.amazonaws.com/192850933622/demoman.fifo',
            MessageGroupId: formData.userId, // Using userId as the MessageGroupId for FIFO queue
            MessageDeduplicationId: `${formData.userId}-${Date.now()}` // Adding a MessageDeduplicationId
        };

        // Send the message to SQS
        await sqs.sendMessage(params).promise();

        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Message sent to SQS successfully' })
        };
    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Error processing request', error: error.message })
        };
    }
};