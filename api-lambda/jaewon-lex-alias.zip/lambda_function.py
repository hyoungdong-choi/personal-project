import json

def lambda_handler(event, context):
    if 'sessionState' not in event:
        return {
            'statusCode': 400,
            'body': json.dumps('sessionState 키를 찾을 수 없습니다.')
        }
    
    session_state = event['sessionState']
    if 'intent' not in session_state:
        return {
            'statusCode': 400,
            'body': json.dumps('intent 키를 찾을 수 없습니다.')
        }
    
    intent = session_state['intent']
    intent_name = intent['name']
    slots = intent.get('slots', {})
    
    if intent_name == 'departureIntent':
        departure = slots.get('departure')
        if not departure:
            return {
                'sessionState': {
                    'dialogAction': {
                        'type': 'ElicitSlot',
                        'slotToElicit': 'departure',
                        'message': {'contentType': 'PlainText', 'content': '현재 출발할 수 있는 공항은 김포공항과 인천국제공항입니다. 다시 말해주세요.'}
                    },
                    'intent': intent
                }
            }
        
    elif intent_name == 'destinationIntent':
        destination = slots.get('destination')
        if not destination:
            return {
                'sessionState': {
                    'dialogAction': {
                        'type': 'ElicitSlot',
                        'slotToElicit': 'destination',
                        'message': {'contentType': 'PlainText', 'content': '현재 갈 수 있는 곳은 도쿄 하네다공항, 도쿄 나리타 공항, 그리고 오사카 공항입니다. 다시 말해주세요.'}
                    },
                    'intent': intent
                }
            }
        
    elif intent_name == 'departureDateIntent':
        departure_date = slots.get('departureDate')
        if not departure_date:
            return {
                'sessionState': {
                    'dialogAction': {
                        'type': 'ElicitSlot',
                        'slotToElicit': 'departureDate',
                        'message': {'contentType': 'PlainText', 'content': '알맞는 입력값을 넣어주세요. 예시 x월 x일 혹은 다음 주 x요일. 다시 말해주세요.'}
                    },
                    'intent': intent
                }
            }
        
    elif intent_name == 'returnDateIntent':
        return_date = slots.get('returnDate')
        if not return_date:
            return {
                'sessionState': {
                    'dialogAction': {
                        'type': 'ElicitSlot',
                        'slotToElicit': 'returnDate',
                        'message': {'contentType': 'PlainText', 'content': '알맞는 입력값을 넣어주세요. 예시 x월 x일 혹은 다음 주 x요일. 다시 말해주세요.'}
                    },
                    'intent': intent
                }
            }
        
    elif intent_name == 'numticketIntent':
        num_tickets = slots.get('numTickets')
        if not num_tickets:
            return {
                'sessionState': {
                    'dialogAction': {
                        'type': 'ElicitSlot',
                        'slotToElicit': 'numTickets',
                        'message': {'contentType': 'PlainText', 'content': '알맞는 숫자를 넣어주세요. 다시 말해주세요.'}
                    },
                    'intent': intent
                }
            }
        
    else:
        # FallbackIntent 처리
        return {
            'sessionState': {
                'dialogAction': {
                    'type': 'ElicitIntent',
                    'message': {'contentType': 'PlainText', 'content': '죄송합니다. 다시 말해주세요.'}
                },
                'intent': intent
            }
        }
    
    # 다음 슬롯을 확인하거나 최종 예약을 완료하는 등의 작업을 수행할 수 있습니다.
    # 이후 적절한 응답을 반환합니다.
    return {
        'sessionState': {
            'dialogAction': {
                'type': 'Close',
                'fulfillmentState': 'Fulfilled',
                'intent': intent,
                'message': {'contentType': 'PlainText', 'content': '예매가 완료되었습니다. 감사합니다!'}
            }
        }
    }
