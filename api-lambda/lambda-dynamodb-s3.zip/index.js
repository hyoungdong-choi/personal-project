            const aws = require('aws-sdk');
const s3 = new aws.S3();
const bucketName = 's3-lambda-ses';

exports.handler = async (event) => {
    try {
        for (const record of event.Records) {
            if (record.eventName === 'INSERT') {
                const item = aws.DynamoDB.Converter.unmarshall(record.dynamodb.NewImage);
                const objectKey = `data-${item.username}-${Date.now()}.json`;
            const objectData = JSON.stringify(item);

                const params = {
                    Bucket: bucketName,
                    Key: objectKey,
                    Body: objectData,
                    ContentType: 'application/json'
                };

                await s3.putObject(params).promise();
                console.log(`Data saved to S3: ${objectKey}`);
            }
        }
    } catch (error) {
        console.error('Error:', error);
        throw error;
    }
};
  