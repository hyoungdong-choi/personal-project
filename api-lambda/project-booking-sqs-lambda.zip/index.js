const AWS = require('aws-sdk');
const dynamodb = new AWS.DynamoDB.DocumentClient();
const s3 = new AWS.S3();

exports.handler = async (event) => {
    for (const record of event.Records) {
        const requestBody = JSON.parse(record.body);
        const { username, Number, airline, departure, departureDate, destination, returnDate, price, passengers } = requestBody;

        // Flight_List 테이블에서 현재 항공편 정보 가져오기
        const getFlightParams = {
            TableName: 'Flight_List',
            Key: { 'Number': Number }
        };

        try {
            const flightData = await dynamodb.get(getFlightParams).promise();
            const flight = flightData.Item;

            if (!flight) {
                console.error(`Flight not found with number: ${Number}`);
                // 에러 처리 로직을 여기에 추가합니다.
                continue;
            }

            if (flight.bookedSeats + passengers > flight.totalSeats) {
                console.error('Not enough seats available');
                // 에러 처리 로직을 여기에 추가합니다.
                continue;
            }

            // Flight_List 테이블의 bookedSeats 업데이트
            const updateFlightParams = {
                TableName: 'Flight_List',
                Key: { 'Number': Number },
                UpdateExpression: 'set bookedSeats = bookedSeats + :val',
                ExpressionAttributeValues: { ':val': passengers },
                ReturnValues: 'UPDATED_NEW'
            };
            await dynamodb.update(updateFlightParams).promise();
            console.log(`Updated booked seats for flight number: ${Number}`);

            // Reservation_Info 테이블에 예약 정보 저장
            const reservationDBParams = {
                TableName: 'Reservation_Info',
                Item: {
                    'username': username,
                    'airline': airline,
                    'departure': departure,
                    'departureDate': departureDate,
                    'destination': destination,
                    'returnDate': returnDate,
                    'price': price,
                    'passengers': passengers
                }
            };
            await dynamodb.put(reservationDBParams).promise();
            console.log('Reservation saved to DynamoDB');
            
            const s3Params = {
                Bucket: 'project-athena-business-log-0000', // 실제 S3 버킷 이름으로 대체하세요
                Key: `bookedlist/${username}-${Date.now()}.json`, // 파일 이름은 유니크하게 설정하세요
                Body: JSON.stringify(requestBody),
                ContentType: 'application/json'
            };
            
            await s3.putObject(s3Params).promise();
            console.log('Reservation data saved to S3');

        } catch (error) {
            console.error('Error processing the reservation:', error);
            // 에러 처리 로직을 여기에 추가합니다.
        }
    }
};
