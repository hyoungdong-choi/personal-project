import json

def lambda_handler(event, context):
    # 사용자의 입력 메시지 추출
    user_input = event['inputTranscript']
    
    # 사용자의 입력이 "안녕"인 경우 Welcome Intent를 반환
    if user_input == "안녕":
        response = {
            'message': "안녕하세요! 항상 친절한 재원봇입니다. 여행을 예약하고 싶으신가요?",
            'intentName': 'WelcomeIntent'
        }
    # Welcome Intent 이후 자동으로 bookingIntent를 실행
    elif event['currentIntent']['name'] == 'WelcomeIntent':
        response = {
            'message': "어디로 여행을 가고 싶으세요?",
            'intentName': 'bookingIntent'
        }
    # 그 외의 경우에는 Welcome Intent를 반환
    else:
        response = {
            'message': "안녕하세요! 항상 친절한 재원봇입니다. 무엇을 도와드릴까요?",
            'intentName': 'WelcomeIntent'
        }

    return {
        'statusCode': 200,
        'body': json.dumps(response)
    }
