const AWS = require('aws-sdk');
const mysql = require('mysql');
const bcrypt = require('bcryptjs');

const dbConfig = {
    host: process.env.RDS_ENDPOINT,
    user: process.env.DB_USERNAME,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME
};

exports.handler = async (event) => {
    try {
        console.log('Received event:', JSON.stringify(event, null, 2)); // event를 로그로 출력

        // 직접 필드를 추출하여 eventData 객체 생성
        const { username, email, phoneNumber, password, address } = event;

        // 비밀번호 확인
        if (!password) {
            throw new Error('비밀번호가 누락되었습니다.');
        }

        const connection = mysql.createConnection(dbConfig);
        const hash = await bcrypt.hash(password, 10);
        
        const insertQuery = 'INSERT INTO Customers (username, email, phoneNumber, password, address) VALUES (?, ?, ?, ?, ?)';
        const values = [username, email, phoneNumber, hash, address];
        
        const insertResult = await new Promise((resolve, reject) => {
            connection.query(insertQuery, values, (error, results) => {
                if (error) {
                    reject(error);
                } else {
                    resolve(results);
                }
            });
        });

        console.log('Data inserted successfully: ', insertResult);
        connection.end();

        const response = {
    statusCode: 200,
    headers: {
        'Access-Control-Allow-Origin': 'd1xku8loyv7969.cloudfront.net', // CORS 헤더 설정
        'Content-Type': 'application/json'
    },
    body: JSON.stringify({ message: 'Registration successful' })
};

console.log('Response:', JSON.stringify(response)); // 응답 로그 추가

return response; // 응답 반환

        
    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: error.statusCode || 500,
            headers: {
                'Access-Control-Allow-Origin': 'd1xku8loyv7969.cloudfront.net', // CORS 헤더 설정
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ message: error.message || 'An error occurred during registration' })
        };
    }
};
