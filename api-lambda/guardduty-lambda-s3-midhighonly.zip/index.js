const AWS = require('aws-sdk');
const s3 = new AWS.S3();

exports.handler = async (event) => {
    const bucketName = 'guardduty-malware-s3'; // S3 버킷 이름
    const objectKey = `filtered-guardduty-findings-${Date.now()}.json`; // 파일 이름
    const severityThreshold = 4.0; // 중간 및 높은 severity의 임계값

    try {
        // EventBridge에서 받은 GuardDuty findings
        const findings = event.detail.findings;
        const filteredFindings = findings.filter(finding => finding.severity >= severityThreshold);

        if (filteredFindings.length > 0) {
            // S3에 필터링된 findings를 JSON 형식으로 저장
            await s3.putObject({
                Bucket: bucketName,
                Key: objectKey,
                Body: JSON.stringify(filteredFindings),
                ContentType: 'application/json'
            }).promise();

            console.log(`Filtered GuardDuty findings saved to ${bucketName}/${objectKey}`);
        } else {
            console.log('No findings with middle or high severity.');
        }

        return { statusCode: 200, body: JSON.stringify({ message: 'Success' }) };
    } catch (error) {
        console.error('Error processing GuardDuty findings:', error);
        return { statusCode: 500, body: JSON.stringify({ message: 'Error' }) };
    }
};
