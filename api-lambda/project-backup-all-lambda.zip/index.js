const AWS = require('aws-sdk');
const https = require('https');
const fs = require('fs');
const path = require('path');

const lambda = new AWS.Lambda();
const s3 = new AWS.S3();
const s3BucketName = 'project-backup-all-lambda-0000';

exports.handler = async (event) => {
    try {
        const functions = await lambda.listFunctions().promise();
        const backupTasks = functions.Functions.map(func => {
            const functionName = func.FunctionName;
            const functionData = lambda.getFunction({ FunctionName: functionName }).promise();
            return functionData.then(data => {
                const codeUrl = data.Code.Location;
                return downloadAndUpload(codeUrl, `${functionName}.zip`);
            });
        });

        await Promise.all(backupTasks);
        return { message: 'Backup completed successfully' };
    } catch (error) {
        console.error('Error during backup:', error);
        throw error;
    }
};

const downloadAndUpload = (url, fileName) => {
    return new Promise((resolve, reject) => {
        const filePath = path.join('/tmp', fileName);
        const file = fs.createWriteStream(filePath);

        https.get(url, (response) => {
            response.pipe(file);
            file.on('finish', () => {
                file.close(async () => {
                    console.log(`Downloaded ${fileName}`);

                    const fileStream = fs.createReadStream(filePath);
                    try {
                        await s3.upload({
                            Bucket: s3BucketName,
                            Key: fileName,
                            Body: fileStream
                        }).promise();

                        console.log(`Uploaded ${fileName} to S3`);
                        resolve();
                    } catch (uploadError) {
                        console.error(`Error uploading ${fileName}:`, uploadError);
                        reject(uploadError);
                    }
                });
            });
        }).on('error', (downloadError) => {
            console.error(`Error downloading ${fileName}:`, downloadError);
            fs.unlink(filePath, () => reject(downloadError));
        });
    });
};
