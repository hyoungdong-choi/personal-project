const AWS = require('aws-sdk');
const s3 = new AWS.S3();
const dynamoDB = new AWS.DynamoDB.DocumentClient();

const tableName = 'Flight_List';
const bucketName = 'project-dynamodb-backup-storage-0000';
const backupFileName = `flightlist/dynamodb-backup-${Date.now()}.json`;

exports.handler = async (event) => {
    try {
        // DynamoDB 테이블에서 데이터 스캔
        const data = await dynamoDB.scan({ TableName: tableName }).promise();
        
        // S3에 데이터 저장
        await s3.putObject({
            Bucket: bucketName,
            Key: backupFileName,
            Body: JSON.stringify(data.Items),
            ContentType: 'application/json'
        }).promise();

        console.log('Backup successful:', backupFileName);
    } catch (error) {
        console.error('Error during backup:', error);
        throw error;
    }
};
