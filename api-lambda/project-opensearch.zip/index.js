const { S3Client, ListObjectsV2Command, GetObjectCommand } = require("@aws-sdk/client-s3");
const axios = require('axios');
const streamToString = require('stream-to-string');

// AWS 및 OpenSearch 설정
const s3Client = new S3Client({ region: "ap-northeast-2" });
const bucketName = "project-athena-business-log-0000";
const openSearchDomain = "https://search-jaewon-flight-ccax2dwqekb4qv6xgl5rza2ajq.ap-northeast-2.es.amazonaws.com";
const index = "project";
const folderPrefix = "bookedlist/"; // 특정 폴더를 지정합니다.

async function listS3Objects() {
  const command = new ListObjectsV2Command({
    Bucket: bucketName,
    Prefix: folderPrefix, // 특정 폴더 내의 파일만 나열합니다.
  });
  const response = await s3Client.send(command);
  return response.Contents; // 파일 목록 반환
}

async function readS3ObjectAndIndexToOpenSearch(key) {
    const getObjectCommand = new GetObjectCommand({
      Bucket: bucketName,
      Key: key,
    });
    const { Body } = await s3Client.send(getObjectCommand);
    
    const jsonData = await streamToString(Body);
  
    // 인증 정보를 Base64로 인코딩합니다.
    const username = 'choi';
    const password = 'Dkagh1.dkagh1.';
    const base64Credentials = Buffer.from(`${username}:${password}`).toString('base64');
  
    // OpenSearch에 삽입
    const response = await axios.post(`${openSearchDomain}/${index}/_doc`, JSON.parse(jsonData), {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Basic ${base64Credentials}`, // 인증 헤더를 추가합니다.
      },
    });
  
    return response.data;
  }

exports.handler = async (event) => {
  try {
    const objects = await listS3Objects();
    const results = await Promise.all(objects.map(async (object) => {
      // 폴더 내 파일만 처리합니다.
      if (object.Key.startsWith(folderPrefix)) {
        return readS3ObjectAndIndexToOpenSearch(object.Key);
      }
    }));
    
    // 결과 배열에서 undefined를 제거합니다.
    const filteredResults = results.filter(result => result !== undefined);

    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Successfully processed files.', results: filteredResults }),
    };
  } catch (error) {
    console.error('Error processing files:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Error processing files.', error }),
    };
  }
};
