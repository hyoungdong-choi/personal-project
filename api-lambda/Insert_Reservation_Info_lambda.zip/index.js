const AWS = require('aws-sdk');
const dynamoDB = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
    // 예약 상세 정보를 파싱합니다.
    const body = JSON.parse(event.body);

    // DynamoDB put 작업에 대한 매개변수를 정의합니다.
    const params = {
        TableName: 'Reservation_Info',
        Item: {
            'reservationID': body.reservationID,
            'userID': body.userID,
            'airline': body.airline,
            'departure': body.departure,
            'departureDate': body.departureDate,
            'destination': body.destination,
            'returnDate': body.returnDate,
            'seatID': body.seatID
        }
    };

    // put 작업을 수행합니다.
    try {
        const data = await dynamoDB.put(params).promise();
        return {
            statusCode: 200,
            body: '예약완료',
        };
    } catch (error) {
        console.log(error);
        return {
            statusCode: 500,
            body: '예약실패',
        };
    }
};