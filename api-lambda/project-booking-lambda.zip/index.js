// 필요한 모듈을 로드합니다.
const AWS = require('aws-sdk');
const jwt = require('jsonwebtoken');
const sqs = new AWS.SQS();

exports.handler = async (event) => {
    try {
        const headers = event.headers;
        const token = headers.Authorization || headers.authorization;

        if (!token) {
            return response(401, 'Authorization token not provided');
        }

        const tokenValue = token.startsWith('Bearer ') ? token.split(' ')[1] : token;
        const decoded = jwt.verify(tokenValue, process.env.JWT_SECRET_KEY);

        const requestBody = JSON.parse(event.body);
        const passengers = parseInt(requestBody.passengers, 10);
        if (isNaN(passengers) || passengers < 1 || passengers > 9) {
            return response(400, 'Invalid passengers value');
        }

        const messageBody = JSON.stringify({
            ...requestBody,
            username: decoded.username
        });

        const sendToQueueParams = {
            MessageBody: messageBody,
            QueueUrl: process.env.SQS_QUEUE_URL
        };

        await sqs.sendMessage(sendToQueueParams).promise();
        return response(200, 'Reservation request sent to the queue.');

    } catch (error) {
        console.error('Error processing the request:', error);
        return response(500, `Error processing reservation: ${error.message}`);
    }
};

function response(statusCode, message) {
    return {
        statusCode: statusCode,
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Credentials': true
        },
        body: JSON.stringify({ message: message })
    };
}
