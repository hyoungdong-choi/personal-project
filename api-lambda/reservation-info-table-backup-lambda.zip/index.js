const AWS = require('aws-sdk');
const s3 = new AWS.S3();

exports.handler = async (event, context) => {
  const s3Bucket = 'reservation-info-table-backup-bucket'; // 변경 필요: 백업을 저장할 S3 버킷 이름
  const s3Prefix = ''; // 변경 필요: S3 버킷 내 백업 파일의 접두사

  for (const record of event.Records) {
    const eventName = record.eventName;

    if (eventName === 'INSERT' || eventName === 'MODIFY') {
      // 새로운 데이터를 가져와서 DynamoDB 아이템을 JavaScript 객체로 변환
      const newItem = AWS.DynamoDB.Converter.unmarshall(record.dynamodb.NewImage);

      // 필요한 속성 추출
      const { username, airline, departure, departureDate, destination, passengers, returnDate } = newItem;

      // S3에 업로드할 파일의 키 생성
      const s3Key = `${s3Prefix}${username}_${record.eventID}.json`;

      // S3에 데이터 업로드
      const params = {
        Bucket: s3Bucket,
        Key: s3Key,
        Body: JSON.stringify({
          username,
          airline,
          departure,
          departureDate,
          destination,
          passengers,
          returnDate,
        }),
      };

      try {
        // S3 업로드 실행
        await s3.upload(params).promise();
        console.log(`S3로 데이터 업로드 완료: ${s3Key}`);
      } catch (error) {
        console.error(`S3로 데이터 업로드 중 오류 발생: ${error.message}`);
      }
    } else if (eventName === 'REMOVE') {
      // 삭제된 데이터의 키를 생성
      const removedUsername = AWS.DynamoDB.Converter.unmarshall(record.dynamodb.Keys).username;
      const s3Key = `${s3Prefix}${removedUsername}_${record.eventID}_removed.json`;

      // S3에 삭제된 데이터의 표시만을 업로드
      const removedData = { removed: true };
      const removedParams = {
        Bucket: s3Bucket,
        Key: s3Key,
        Body: JSON.stringify(removedData),
      };

      try {
        // S3 업로드 실행
        await s3.upload(removedParams).promise();
        console.log(`S3로 삭제된 데이터 표시 업로드 완료: ${s3Key}`);
      } catch (error) {
        console.error(`S3로 삭제된 데이터 표시 업로드 중 오류 발생: ${error.message}`);
      }
    }
  }

  return {
    statusCode: 200,
    body: JSON.stringify('백업이 성공적으로 완료됨'),
  };
};