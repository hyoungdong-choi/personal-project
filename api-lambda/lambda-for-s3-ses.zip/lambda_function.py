import json
import boto3

def lambda_handler(event, context):
    # Initialize the S3 client
    s3_client = boto3.client('s3')
    
    # Extract the file name and bucket name from the event
    file_name = event['Records'][0]['s3']['object']['key']
    bucket_name = event['Records'][0]['s3']['bucket']['name']
    
    # Retrieve the file content from S3
    file_content = s3_client.get_object(Bucket=bucket_name, Key=file_name)
    file_text = file_content["Body"].read().decode('utf-8')
    
    # Deserialize the file content
    json_content = json.loads(file_text)
    
    # Extract fields from the JSON content
    username = json_content.get("username", "Not provided")
    email = json_content.get("email", "Not provided")
    
    # Set up the subject and body of the email
    subject = f'New file {file_name} uploaded to {bucket_name}'
    additional_message = "JaewonFlight 서비스를 이용해주셔서 감사합니다. 저희 서비스를 재이용 시 10% 할인 혜택을 드리고 있습니다. 감사합니다."
    body = f"""
        <html>
            <head></head>
            <body>
                <h1>S3 Event Notification</h1>
                <p>A file with the following details has been uploaded to the {bucket_name} bucket:</p>
                <ul>
                    <li>Username: {username}</li>
                    <li>Email: {email}</li>
                </ul>
                <p>{additional_message}</p>
            </body>
        </html>
    """
    
    # Set up the SES client
    ses_client = boto3.client("ses")
    
    # Construct the message
    message = {
        "Subject": {"Data": subject},
        "Body": {"Html": {"Data": body}}
    }
    
    # Send the email
    response = ses_client.send_email(
        Source="path0971@naver.com",
        Destination={"ToAddresses": ["path0971@naver.com"]},
        Message=message
    )
    
    print("The email has been sent successfully")
    return response
