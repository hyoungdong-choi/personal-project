const AWS = require('aws-sdk');
const s3 = new AWS.S3();

exports.handler = async (event) => {
    const bucketName = 'project-log-cloudfront-bucket-0000';
    const today = new Date();
    const year = today.getFullYear();
    const month = ('0' + (today.getMonth() + 1)).slice(-2);
    const week = getWeekNumber(today);

    try {
        const listParams = {
            Bucket: bucketName,
            Prefix: 'logs/' // logs 디렉토리 내부의 파일들만 대상으로 합니다.
        };

        const listedObjects = await s3.listObjectsV2(listParams).promise();
        const gzFiles = listedObjects.Contents.filter(object => object.Key.endsWith('.gz'));

        if (gzFiles.length === 0) return;

        for (const object of gzFiles) {
            const fileKey = object.Key;
            const newKey = `year-${year}/month-${month}/week-${week}/${fileKey.split('/').pop()}`;

            // 새 위치에서 동일한 파일 이름이 있는지 확인
            const headParams = {
                Bucket: bucketName,
                Key: newKey
            };

            try {
                // 파일이 존재하는지 확인
                await s3.headObject(headParams).promise();
                console.log(`File already exists: ${newKey}`);
                continue; // 파일이 이미 존재하면, 덮어쓰기를 방지하기 위해 건너뜁니다.
            } catch (headErr) {
                // 파일이 존재하지 않는 경우에만 복사를 진행
                if (headErr.code === 'NotFound') {
                    // 파일 복사
                    const copyResult = await s3.copyObject({
                        Bucket: bucketName,
                        CopySource: `${bucketName}/${fileKey}`,
                        Key: newKey
                    }).promise();

                    if (copyResult) {
                        // 원본 파일 삭제
                        await s3.deleteObject({
                            Bucket: bucketName,
                            Key: fileKey
                        }).promise();
                    }
                } else {
                    throw headErr; // 다른 오류 발생 시 처리
                }
            }
        }

        return {
            statusCode: 200,
            body: JSON.stringify('GZ log files have been organized by year, month, and week.'),
        };
    } catch (error) {
        console.error('Error during the GZ file organization process:', error);
        return {
            statusCode: 500,
            body: JSON.stringify('Error during GZ file organization.'),
        };
    }
};

function getWeekNumber(d) {
    d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
    d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
    const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    const weekNo = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
    return weekNo;
}
