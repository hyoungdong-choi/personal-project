const AWS = require('aws-sdk');
const dynamoDB = new AWS.DynamoDB.DocumentClient();
const s3 = new AWS.S3();


exports.handler = async (event) => {
    try {
        let params = { TableName: 'Flight_List' };

        // 'realtime' 쿼리 매개변수가 있는 경우 실시간 좌석 정보 처리
        if (event.queryStringParameters && event.queryStringParameters.realtime) {
            // 실시간 좌석 정보 로직
        } else {
            // 기본 항공편 검색 로직
        }

        const results = await dynamoDB.scan(params).promise();
        const formattedData = formatDataForWeb(results.Items);

        return {
            statusCode: 200,
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "d1xku8loyv7969.cloudfront.net	"
            },
            body: JSON.stringify(formattedData)
        };
    } catch (error) {
        console.error(error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'An error occurred while retrieving data' })
        };
    }
};

function formatDataForWeb(items) {
    return items.map(item => {
        // 남은 좌석 수 계산
        const seatsAvailable = item.totalSeats - item.bookedSeats;
        return {
            ...item,
            seatsAvailable: seatsAvailable
        };
    });
};

