const AWS = require('aws-sdk');

exports.handler = async (event) => {
    // 스트림 레코드를 반복하여 각 예약 정보를 처리
    for (const record of event.Records) {
        // DynamoDB 스트림에서 새로운 이미지 정보 추출
        const reservation_info = record.dynamodb.NewImage;

        // 예약 정보에서 필요한 데이터 추출
        const username = reservation_info.username.S;
        const airline = reservation_info.airline.S;
        const departure = reservation_info.departure.S;
        const departureDate = reservation_info.departureDate.S;
        const destination = reservation_info.destination.S;
        const passengers = reservation_info.passengers.N;
        const returnDate = reservation_info.returnDate ? reservation_info.returnDate.S : 'N/A';  // returnDate가 없는 경우에 대비

        // SNS 메시지 생성
        let sns_message = "예약이 확인되었습니다.\n\n";
        sns_message += `사용자명: ${username}\n`;
        sns_message += `항공사: ${airline}\n`;
        sns_message += `출발지: ${departure}\n`;
        sns_message += `출발일: ${departureDate}\n`;
        sns_message += `도착지: ${destination}\n`;
        sns_message += `승객 수: ${passengers}\n`;
        sns_message += `귀국일: ${returnDate}\n`;

        // SNS 클라이언트 생성
        const sns_client = new AWS.SNS();

        // SNS 메시지를 보낼 주제 ARN (여기에 실제 ARN을 넣어야 합니다)
        const sns_topic_arn = 'arn:aws:sns:ap-northeast-2:192850933622:Jaewon_reservation_check';

        // SNS 메시지 전송
        await sns_client.publish({
            TopicArn: sns_topic_arn,
            Message: sns_message,
            Subject: "항공편 예약 확인"
        }).promise();
    }
    
    return "처리가 완료되었습니다";
};
