const AWS = require('aws-sdk');
const s3 = new AWS.S3();
const dynamoDB = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
    // S3에서 백업 데이터 목록을 가져옵니다.
    const s3List = await s3.listObjectsV2({
        Bucket: 'project-dynamodb-backup-storage-0000',
        Prefix: 'flightlist/'
    }).promise();
    
    // "flightlist" 디렉토리 내의 객체 목록을 가져왔습니다.
    
    // 가장 최신 파일을 선택합니다.
    let latestFileKey;
    let latestFileDate = new Date(0); // 초기값을 1970년 1월 1일로 설정
    
    for (const object of s3List.Contents) {
        const objectDate = object.LastModified;
        if (objectDate > latestFileDate) {
            latestFileDate = objectDate;
            latestFileKey = object.Key;
        }
    }
    
    if (!latestFileKey) {
        console.log('복구할 파일을 찾을 수 없습니다.');
        return;
    }
    
    // 가장 최신 파일을 가져옵니다.
    const s3Data = await s3.getObject({
        Bucket: 'project-dynamodb-backup-storage-0000',
        Key: latestFileKey
    }).promise();
    
    const items = JSON.parse(s3Data.Body.toString('utf-8'));

    // DynamoDB 테이블에 데이터를 복구합니다.
    for (let item of items) {
        await dynamoDB.put({
            TableName: 'Flight_List',
            Item: item
        }).promise();
    }

    console.log('복구가 완료되었습니다.');
};
