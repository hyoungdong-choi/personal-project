const AWS = require('aws-sdk');
const s3 = new AWS.S3();
const dynamoDB = new AWS.DynamoDB.DocumentClient();

// Lambda 함수의 메인 핸들러
exports.handler = async (event) => {
    const tableName = "Reservation_Info"; // 새로 생성할 DynamoDB 테이블 이름
    const bucketName = "reservation-info-table-backup-bucket"; // S3 버킷 이름

    try {
        // DynamoDB 테이블 생성
        await createTable(tableName);

        // S3 버킷의 모든 파일 목록 가져오기
        const objects = await listAllObjects({ Bucket: bucketName });

        // username별 최신 데이터 저장을 위한 객체
        let latestDataForUser = {};

        // 각 파일 처리
        for (const object of objects) {
            // S3 버킷에서 객체 데이터 가져오기
            const data = await s3.getObject({ Bucket: bucketName, Key: object.Key }).promise();
            const items = JSON.parse(data.Body.toString()); // 데이터를 JSON 형태로 파싱

            // 각 항목 처리
            for (const item of items) {
                const username = item.username; // 항목에서 username 추출
                const backupTime = new Date(object.LastModified); // 파일의 마지막 수정 시간을 백업 시간으로 사용

                // 동일한 username을 가진 데이터 중에서 가장 최근 데이터만 저장
                if (!latestDataForUser[username] || latestDataForUser[username].backupTime < backupTime) {
                    latestDataForUser[username] = { item, backupTime };
                }
            }
        }

        // 최신 데이터를 DynamoDB에 삽입
        for (const { item } of Object.values(latestDataForUser)) {
            await dynamoDB.put({ TableName: tableName, Item: item }).promise();
        }

        console.log('최신 데이터 복원 완료');
    } catch (error) {
        console.error('에러 발생:', error);
    }
};

// S3 버킷의 모든 객체를 나열하는 함수
async function listAllObjects(params) {
    let allObjects = [];
    let data;
    do {
        // S3 버킷에서 객체 목록을 가져오기
        data = await s3.listObjectsV2(params).promise();
        allObjects = allObjects.concat(data.Contents); // 가져온 객체 목록을 allObjects 배열에 추가

        // 다음 페이지가 있다면 ContinuationToken으로 다음 데이터 가져오기
        params.ContinuationToken = data.NextContinuationToken;
    } while (data.IsTruncated); // 모든 페이지를 가져올 때까지 반복

    return allObjects;
}

// DynamoDB 테이블 생성 함수
async function createTable(tableName) {
    const params = {
        TableName: tableName,
        KeySchema: [       
            { AttributeName: "username", KeyType: "HASH"},  // 'username'을 파티션 키로 설정
        ],
        AttributeDefinitions: [       
            { AttributeName: "username", AttributeType: "S" }, // 'username'의 속성 타입 정의
        ],
        ProvisionedThroughput: {       
            ReadCapacityUnits: 5, // 읽기 용량 단위 설정
            WriteCapacityUnits: 5 // 쓰기 용량 단위 설정
        }
    };

    // 테이블 생성 요청
    await dynamoDB.createTable(params).promise();
    console.log(`${tableName} 테이블 생성 완료`);
}