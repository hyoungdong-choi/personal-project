const AWS = require('aws-sdk');
const axios = require('axios');
const zlib = require('zlib');
const { S3Client, GetObjectCommand } = require("@aws-sdk/client-s3");

// AWS 설정
const s3 = new AWS.S3();
const cloudwatchlogs = new AWS.CloudWatchLogs();
const s3Client = new S3Client({ region: "ap-northeast-2" });

// OpenSearch 설정
const openSearchDomain = "https://search-jaewon-flight-ccax2dwqekb4qv6xgl5rza2ajq.ap-northeast-2.es.amazonaws.com";
const index = "cloudfront";
const username = 'choi';
const password = 'Dkagh1.dkagh1.';
const base64Credentials = Buffer.from(`${username}:${password}`).toString('base64');

// CloudWatch Logs 설정
const logGroupName = 'CloudFront-log';

async function processLogData(bucket, key) {
    const getObjectParams = { Bucket: bucket, Key: key };
    const data = await s3.getObject(getObjectParams).promise();
    const decompressedData = zlib.gunzipSync(data.Body);
    const logData = decompressedData.toString('utf-8');
    const logLines = logData.trim().split('\n');

    const logEvents = logLines.filter(line => !line.startsWith('#')).map(logLine => {
        const parts = logLine.split(/\s+/);
        return {
            timestamp: new Date(`${parts[0]} ${parts[1]}Z`).getTime(),
            message: JSON.stringify({
                date: parts[0],
                time: parts[1],
                edgeLocation: parts[2],
                scBytes: parts[3],
                clientIp: parts[4],
                requestMethod: parts[5],
                Host: parts[6],
                UriStem: parts[7],
                StatusCode: parts[8],
                csUserAgent: parts[10],
                csUriQuery: parts[11],
                timeTaken: parts[17],
            }),
        };
    });

    return logEvents;
}

async function sendLogsToCloudWatch(logEvents) {
    const logStreamName = `cloudfront-access-log-${new Date().toISOString().replace(/[:\-]|\.\d{3}/g, '')}`;
    await cloudwatchlogs.createLogStream({ logGroupName, logStreamName }).promise();

    let nextSequenceToken = null; // 첫 번째 putLogEvents 호출에는 sequenceToken이 필요하지 않습니다.

    // CloudWatch Logs에 로그 이벤트를 배치로 전송합니다.
    await cloudwatchlogs.putLogEvents({
        logGroupName,
        logStreamName,
        logEvents,
        sequenceToken: nextSequenceToken
    }).promise();
}

async function indexLogsToOpenSearch(logEvents) {
    for (const logEvent of logEvents) {
        await axios.post(`${openSearchDomain}/${index}/_doc`, JSON.parse(logEvent.message), {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Basic ${base64Credentials}`,
            },
        });
    }
}

exports.handler = async (event) => {
    try {
        const bucket = event.Records[0].s3.bucket.name;
        const key = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, " "));

        // 'logs/' 폴더에 있는 파일만 처리합니다.
        if (!key.startsWith('logs/')) {
            console.log(`The file ${key} is not in the logs directory. Ignoring.`);
            return { statusCode: 200, body: JSON.stringify({ message: 'File ignored.' }) };
        }

        const logEvents = await processLogData(bucket, key);

        await sendLogsToCloudWatch(logEvents);
        await indexLogsToOpenSearch(logEvents);

        return { statusCode: 200, body: JSON.stringify({ message: 'Successfully processed logs.' }) };
    } catch (error) {
        console.error('Error:', error);
        return { statusCode: 500, body: JSON.stringify({ message: 'Error processing logs.', error }) };
    }
};
