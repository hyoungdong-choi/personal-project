import json

def lambda_handler(event, context):
    # event에서 사용자 입력 메시지를 가져옴
    user_message = event['inputTranscript']
    
    # 사용자 입력 메시지에 따른 응답 생성
    if user_message == '안녕':
        response_message = '안녕하세요! 무엇을 도와드릴까요?'
    elif user_message == '날씨 알려줘':
        response_message = '현재 날씨는 맑습니다.'
    else:
        response_message = '죄송합니다. 이해하지 못했습니다.'
    
    # Lambda 함수가 반환하는 응답 형식
    return {
        'sessionAttributes': event['sessionAttributes'],
        'dialogAction': {
            'type': 'Close',
            'fulfillmentState': 'Fulfilled',
            'message': {
                'contentType': 'PlainText',
                'content': response_message
            }
        }
    }
