const mysql = require('mysql2/promise');
const AWS = require('aws-sdk');
const sqs = new AWS.SQS({ region: 'ap-northeast-2' });

exports.handler = async (event) => {
    console.log('Function start');
    const dbConfig = {
        host: 'cutomer-list.cpioesy0wblz.ap-northeast-2.rds.amazonaws.com',
        user: 'admin',
        password: 'dkagh1.dkagh1.',
        database: 'OurCustomer'
    };

    let connection;
    let errorResponse;

    try {
        console.log('Connecting to RDS with config:', JSON.stringify(dbConfig, null, 2).replace(/"password": ".+?"/, '"password": "*****"'));
        connection = await mysql.createConnection(dbConfig);
        console.log('RDS connection successful');

        const records = event.Records;

        // 비동기 처리를 위한 Promise 배열 생성
        const asyncTasks = records.map(async (record) => {
            console.log(`Processing record: ${record.eventID}`);
            if (record.eventName === 'INSERT') {
                console.log('Unmarshalling DynamoDB record');
                const dynamoDBRecord = AWS.DynamoDB.Converter.unmarshall(record.dynamodb.NewImage);
                const username = dynamoDBRecord.username;

                console.log(`Fetching user information for username: ${username}`);
                const query = 'SELECT username, email FROM Customers WHERE username = ?';
                console.log(`Executing query: ${query} with username: ${username}`);
                const [rows] = await connection.execute(query, [username]);
                console.log(`User information fetched: ${rows.length} records found`);

                if (rows.length > 0) {
                    const sqsMessage = {
                        username: rows[0].username,
                        email: rows[0].email
                    };

                    console.log(`Preparing to send message to SQS: ${JSON.stringify(sqsMessage)}`);
                    const sqsParams = {
                        QueueUrl: 'https://sqs.ap-northeast-2.amazonaws.com/192850933622/demoman.fifo',
                        MessageBody: JSON.stringify(sqsMessage),
                        MessageGroupId: rows[0].username,
                        MessageDeduplicationId: `${rows[0].username}-${Date.now()}`
                    };

                    console.log(`Sending message to SQS with params: ${JSON.stringify(sqsParams)}`);
                    // 비동기적으로 메시지 전송
                    await sqs.sendMessage(sqsParams).promise();
                    console.log('Message successfully sent to SQS');
                }
            }
        });

        // 모든 비동기 작업을 병렬로 실행
        await Promise.all(asyncTasks);

        console.log('Function execution complete');
    } catch (error) {
        console.error('Error occurred:', error);
        errorResponse = error; // Assign error to the error response variable
    } finally {
        if (connection) {
            console.log('Attempting to close RDS connection');
            await connection.end();
            console.log('RDS connection closed');
        }
    }

    return {
        statusCode: errorResponse ? 500 : 200,
        body: JSON.stringify({
            message: errorResponse ? 'Error processing request' : 'Processing completed',
            error: errorResponse ? errorResponse.toString() : null
        })
    };
};